from . import dashboard
from . import crm_lead
from . import agent_performance
from . import supervisor_dashboard
from . import res_config_settings
from . import lead_history
from . import lead_category